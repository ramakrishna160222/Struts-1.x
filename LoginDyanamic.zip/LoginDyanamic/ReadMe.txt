DataBase Related:
------------------
1. import employee_employee.sql file in mysqlworkbench.
2. Make changes in DAO files according to your credentials like username,password.

Note
----
1. Id "1" is reserved username="krishna" & password="admin".
2. so you can register new user by using "id" from 2 onwards.


